from fastapi_login.exceptions import InvalidCredentialsException
from fastapi import FastAPI, Form, UploadFile, Response
from fastapi.encoders import jsonable_encoder
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from roboflow import Roboflow
from typing import Annotated
import binascii
import sqlite3
import json

con = sqlite3.connect('db.db', check_same_thread=False)
cur = con.cursor()

cur.execute(f"""
            CREATE TABLE IF NOT EXISTS users (
                number INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT NOT NULL,pip 
                id TEXT NOT NULL,
                password TEXT NOT NULL
            );
            """)

cur.execute(f"""
            CREATE TABLE IF NOT EXISTS detect (
                id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                condition TEXT,
                image BLOB
            );
            """)

app = FastAPI()


def query_user(data):
    WHERE_STATEMENTS = f'''id="{data}"'''
    if type(data) == dict:
        WHERE_STATEMENTS = f'''id="{data["id"]}"'''
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    user = cur.execute(f"""
                       SELECT * FROM users WHERE {WHERE_STATEMENTS}
                       """).fetchone()
    return user


@app.post('/signup')
def signup(
    name:Annotated[str, Form()], 
    email:Annotated[str, Form()], 
    id:Annotated[str, Form()], 
    password:Annotated[str, Form()]
    ):

    cur.execute(f"""
                INSERT INTO users(name, email, id, password)
                VALUES ('{name}','{email}','{id}','{password}');
                """)
    con.commit()

    return "200"


@app.post('/login')
def login(
    id:Annotated[str, Form()],
    password:Annotated[str,Form()]):

    user = query_user(id)
    if not user:
        raise InvalidCredentialsException
    elif password != user['password']:
        raise InvalidCredentialsException
    else: return '200'


@app.post('/upload')
async def create_image(image:UploadFile):
    image_name = image.filename

    contents = await image.read()
    with open(f"./upload_img/{image_name}", "wb") as f:
        f.write(contents)


    rf = Roboflow(api_key="wDK3bzsneW0crbvVRixm")
    project = rf.workspace("senior-pscm5").project("senior-yy8zv")
    model = project.version(2).model
    prediction = model.predict(f'./upload_img/{image_name}', confidence=40, overlap=30).json()
    detect_image = model.predict(f'./upload_img/{image_name}', confidence=40, overlap=30).save(f"./detect_img/detect_{image_name}.jpg")

    condition = prediction["predictions"][0]["class"]
    
    detect_image_path = f"./detect_img/detect_{image_name}.jpg"
    with open(detect_image_path, "rb") as f:
        image_data = f.read()
        hex_data = binascii.hexlify(image_data)
        hex_string = hex_data.decode('utf-8')
        
    cur.execute(f"""
                INSERT INTO detect(condition, image)
                VALUES ('{condition}','{hex_string}')
                """)
    con.commit()
    return '200'


@app.get('/detect_image')
async def get_detect_image():
    cur = con.cursor()
    # 16진법
    image_bytes = cur.execute(f"""
                            SELECT image FROM detect ORDER BY ROWID DESC LIMIT 1;
                            """).fetchone()[0]
    
    return Response(content=bytes.fromhex(image_bytes), media_type='image/*')


@app.get('/condition')
async def get_condition():
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    row = cur.execute(f"""
                    SELECT condition FROM detect ORDER BY ROWID DESC LIMIT 1;
                    """).fetchone()[0]
    
    return row


app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
