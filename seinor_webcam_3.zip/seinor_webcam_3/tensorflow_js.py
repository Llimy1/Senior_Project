import tensorflow as tf
import tensorflowjs as tfjs

tf_model = ("C:/Users/10/Desktop/Senior_Project/senior_web/tensorflow_model")

