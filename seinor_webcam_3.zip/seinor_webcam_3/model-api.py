# import onnx
# import tensorflow as tf
# from onnx_tf.backend import prepare

# onnx_model = onnx.load("C:/Users/10/Desktop/Senior_Project/senior_web/lens-studio_senior-yy8zv_v2.onnx")

# tf_rep = prepare(onnx_model)

# tf_model = tf_rep.export_graph("C:/Users/10/Desktop/Senior_Project/senior_web/tf_graph_model")
# tf.saved_model.save(tf_model, "C:/Users/10/Desktop/Senior_Project/senior_web/tensorflow_model")



# tensorflowjs_converter --input_format=tf_saved_model --output_format=tfjs_graph_model --saved_model_tags=serve C:/Users/10/Desktop/seinor_webcam_moblieNet/ssd_mobilenet_v2_2 C:/Users/10/Desktop/seinor_webcam_moblieNet/model